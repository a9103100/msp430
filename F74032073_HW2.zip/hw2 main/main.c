extern unsigned long long int multi(unsigned int, unsigned int,unsigned int, unsigned int);
extern unsigned int digital_sum(unsigned long long int);
extern void LED_blink(unsigned int times);

int main()
{
    unsigned long long int result=0;
    unsigned int a,b,c,d,sum;
    //result=a*b*c*d;
    a=100;
    b=9;
    c=50;
    d=321;
    result = multi(a,b,c,d);
    //if the value of result is 12345610, the sum should be 21;
    sum = digital_sum(result);
    LED_blink(sum);
    return 0;
}
